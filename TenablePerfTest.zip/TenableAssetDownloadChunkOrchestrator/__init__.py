"""Asset DownloadChunk Orchestrator file."""

import json
import logging
import os

import azure.durable_functions as df

from datetime import timedelta
from ..exports_store import (
    ExportsTableStore,
    ExportsTableNames,
    list_tables_in_storage_account,
)

connection_string = os.environ["AzureWebJobsStorage"]
assets_table_name = ExportsTableNames.TenableAssetExportTable.value
assets_table = ExportsTableStore(connection_string, assets_table_name)
download_chunk_schedule_minutes = 1
retry_interval = 5
logs_starts_with = "TenableVM"
function_name = "TenableAssetDownloadChunkOrchestrator"
asset_download_and_process_chunk_activity_name = "TenableAssetDownloadAndProcessChunks"


def check_table_exist():
    """Check if the assets table exists in the storage account.

    Returns:
        True if the table exists, False otherwise.
    """
    tables = list_tables_in_storage_account(connection_string)
    for table in tables:
        if table.name == assets_table_name:
            logging.info(f"{logs_starts_with} {function_name}: {assets_table_name} table exists.")
            return True
    return False


def orchestrator_function(context: df.DurableOrchestrationContext):
    """
    Orchestrator function to handle Tenable.io Asset Export chunks.

    This function is responsible to check if the assets table exists in the storage account.
    If the table exists, it will query for all queued chunks and call the activity function
    `TenableAssetDownloadAndProcessChunks` to download and process the chunks.
    If there are no more chunks to process, it will go to sleep for 1 minute before checking again.
    If the table does not exist, it will go to sleep for 1 minute before checking again.

    Args:
        context (df.DurableOrchestrationContext): The durable orchestration context

    Returns:
        None
    """
    logging.info(f"{logs_starts_with} {function_name}: Starting execution for TenableAssetDownloadChunkOrchestrator")
    logging.info(
        f"{logs_starts_with} {function_name}: instance id: {context.instance_id} at {context.current_utc_datetime}"
    )
    jobs_with_finished_chunks = {}
    # flag = check_table_exist()
    global download_chunk_schedule_minutes
    # if not flag:
    #     logging.info(
    #         f"{logs_starts_with} {function_name}:{assets_table_name} table is not created. waiting for next execution."
    #     )
    #     next_check = context.current_utc_datetime + timedelta(minutes=download_chunk_schedule_minutes)
    #     yield context.create_timer(next_check)
    #     yield context.continue_as_new(None)
    while True:
        download_chunk_schedule_minutes = 1
        # queued_chunks = assets_table.query_for_all_queued_chunks()
        # queued_chunks_list = list(queued_chunks)
        # logging.info(f"{logs_starts_with} {function_name}: Number of queued chunks: {len(queued_chunks_list)}")
        # if len(queued_chunks_list) == 0:
        #     logging.info(
        #         f"{logs_starts_with} {function_name}: No more chunks found to process. Going to sleep for 1 minute..."
        #     )
        #     break
        # sorted_chunks = sorted(queued_chunks_list, key=lambda e: e["ingestTimestamp"])
        # logging.info(f"{logs_starts_with} {function_name}: Sorted chunks: {sorted_chunks}")
        json_data = [
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "4",
        "ingestTimestamp": 1749733108.0710618,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "5",
        "ingestTimestamp": 1749733108.1310403,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "6",
        "ingestTimestamp": 1749733108.1871717,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "7",
        "ingestTimestamp": 1749733108.2371297,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "8",
        "ingestTimestamp": 1749733108.2824228,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "9",
        "ingestTimestamp": 1749733108.3379397,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "10",
        "ingestTimestamp": 1749733108.3837488,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "11",
        "ingestTimestamp": 1749733108.4316185,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "12",
        "ingestTimestamp": 1749733108.4779863,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "13",
        "ingestTimestamp": 1749733108.5316095,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "14",
        "ingestTimestamp": 1749733108.57955,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "15",
        "ingestTimestamp": 1749733108.6380754,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "16",
        "ingestTimestamp": 1749733108.6867962,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "17",
        "ingestTimestamp": 1749733108.73948,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "18",
        "ingestTimestamp": 1749733108.804216,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "19",
        "ingestTimestamp": 1749733108.853169,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "20",
        "ingestTimestamp": 1749733108.9004297,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "21",
        "ingestTimestamp": 1749733108.9443736,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "22",
        "ingestTimestamp": 1749733108.9897604,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "23",
        "ingestTimestamp": 1749733109.0506115,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "24",
        "ingestTimestamp": 1749733109.1150796,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "25",
        "ingestTimestamp": 1749733109.1705472,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "26",
        "ingestTimestamp": 1749733109.2188606,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "27",
        "ingestTimestamp": 1749733109.2692802,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "28",
        "ingestTimestamp": 1749733109.3221042,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "29",
        "ingestTimestamp": 1749733109.366921,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "30",
        "ingestTimestamp": 1749733109.4178135,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "31",
        "ingestTimestamp": 1749733109.4616556,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "32",
        "ingestTimestamp": 1749733109.5047383,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "33",
        "ingestTimestamp": 1749733109.581689,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "34",
        "ingestTimestamp": 1749733109.62723,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "35",
        "ingestTimestamp": 1749733109.6703897,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "36",
        "ingestTimestamp": 1749733109.717797,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "37",
        "ingestTimestamp": 1749733109.7612622,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "38",
        "ingestTimestamp": 1749733109.8001728,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "39",
        "ingestTimestamp": 1749733109.839758,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "40",
        "ingestTimestamp": 1749733109.8771265,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "41",
        "ingestTimestamp": 1749733109.9191828,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "42",
        "ingestTimestamp": 1749733109.960394,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "43",
        "ingestTimestamp": 1749733109.997382,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "44",
        "ingestTimestamp": 1749733110.0351496,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "45",
        "ingestTimestamp": 1749733110.0802684,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "46",
        "ingestTimestamp": 1749733110.1233404,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "47",
        "ingestTimestamp": 1749733110.1613803,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "48",
        "ingestTimestamp": 1749733110.1994815,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "49",
        "ingestTimestamp": 1749733110.2392175,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "50",
        "ingestTimestamp": 1749733110.2779431,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "51",
        "ingestTimestamp": 1749733110.314747,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "52",
        "ingestTimestamp": 1749733110.3590658,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "53",
        "ingestTimestamp": 1749733110.395524,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "54",
        "ingestTimestamp": 1749733110.4342194,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "55",
        "ingestTimestamp": 1749733110.4738977,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "56",
        "ingestTimestamp": 1749733111.519737,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "57",
        "ingestTimestamp": 1749733111.5687976,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "58",
        "ingestTimestamp": 1749733111.6322398,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "59",
        "ingestTimestamp": 1749733111.6789007,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "60",
        "ingestTimestamp": 1749733111.729802,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "61",
        "ingestTimestamp": 1749733111.7779024,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "62",
        "ingestTimestamp": 1749733111.8231761,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "63",
        "ingestTimestamp": 1749733111.881394,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "64",
        "ingestTimestamp": 1749733111.933772,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "65",
        "ingestTimestamp": 1749733111.979803,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "66",
        "ingestTimestamp": 1749733112.0369375,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "67",
        "ingestTimestamp": 1749733112.1000886,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "68",
        "ingestTimestamp": 1749733112.1564326,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "69",
        "ingestTimestamp": 1749733112.211609,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "70",
        "ingestTimestamp": 1749733112.2684844,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "71",
        "ingestTimestamp": 1749733112.3125072,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "72",
        "ingestTimestamp": 1749733112.368531,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "73",
        "ingestTimestamp": 1749733112.4165745,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "74",
        "ingestTimestamp": 1749733112.4707704,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "75",
        "ingestTimestamp": 1749733112.5529468,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "76",
        "ingestTimestamp": 1749733112.600558,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "77",
        "ingestTimestamp": 1749733112.6594815,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "78",
        "ingestTimestamp": 1749733112.7181547,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "79",
        "ingestTimestamp": 1749733112.7674675,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "80",
        "ingestTimestamp": 1749733112.8164585,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "81",
        "ingestTimestamp": 1749733112.8635879,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "82",
        "ingestTimestamp": 1749733112.9130626,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "83",
        "ingestTimestamp": 1749733112.9609306,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "84",
        "ingestTimestamp": 1749733113.0137894,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "85",
        "ingestTimestamp": 1749733113.0649614,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "86",
        "ingestTimestamp": 1749733113.1203895,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "87",
        "ingestTimestamp": 1749733113.1772432,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "88",
        "ingestTimestamp": 1749733114.2208643,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "89",
        "ingestTimestamp": 1749733114.2580323,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "90",
        "ingestTimestamp": 1749733114.296112,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "91",
        "ingestTimestamp": 1749733114.3347745,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "92",
        "ingestTimestamp": 1749733114.3751302,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "93",
        "ingestTimestamp": 1749733114.4170012,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "94",
        "ingestTimestamp": 1749733114.4695947,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "95",
        "ingestTimestamp": 1749733114.5119534,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "96",
        "ingestTimestamp": 1749733114.5560126,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "97",
        "ingestTimestamp": 1749733119.603461,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "98",
        "ingestTimestamp": 1749733119.6464996,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "99",
        "ingestTimestamp": 1749733119.6885571,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "100",
        "ingestTimestamp": 1749733119.7520978,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "101",
        "ingestTimestamp": 1749733119.7950203,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "102",
        "ingestTimestamp": 1749733119.836851,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "103",
        "ingestTimestamp": 1749733119.8781133,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "104",
        "ingestTimestamp": 1749733119.922206,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "105",
        "ingestTimestamp": 1749733119.9603417,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "106",
        "ingestTimestamp": 1749733120.0015988,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "107",
        "ingestTimestamp": 1749733120.0408852,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "108",
        "ingestTimestamp": 1749733120.091528,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "109",
        "ingestTimestamp": 1749733120.1344712,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "110",
        "ingestTimestamp": 1749733120.1870475,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "111",
        "ingestTimestamp": 1749733120.2315245,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "112",
        "ingestTimestamp": 1749733120.3032842,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "113",
        "ingestTimestamp": 1749733120.345969,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "114",
        "ingestTimestamp": 1749733120.3851907,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "115",
        "ingestTimestamp": 1749733120.4432318,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "116",
        "ingestTimestamp": 1749733120.4863622,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "117",
        "ingestTimestamp": 1749733120.5335703,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "118",
        "ingestTimestamp": 1749733120.5836277,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "119",
        "ingestTimestamp": 1749733120.633631,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "120",
        "ingestTimestamp": 1749733120.685757,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "121",
        "ingestTimestamp": 1749733120.738387,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "122",
        "ingestTimestamp": 1749733120.8041222,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "123",
        "ingestTimestamp": 1749733120.8530645,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "124",
        "ingestTimestamp": 1749733120.9024882,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "125",
        "ingestTimestamp": 1749733120.953267,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "126",
        "ingestTimestamp": 1749733120.9981065,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "127",
        "ingestTimestamp": 1749733121.0380554,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "128",
        "ingestTimestamp": 1749733121.0832148,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "129",
        "ingestTimestamp": 1749733121.1279104,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "130",
        "ingestTimestamp": 1749733121.1682,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "131",
        "ingestTimestamp": 1749733121.212815,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "132",
        "ingestTimestamp": 1749733121.2545712,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "133",
        "ingestTimestamp": 1749733121.2957652,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "134",
        "ingestTimestamp": 1749733121.3400636,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "135",
        "ingestTimestamp": 1749733121.3818686,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "136",
        "ingestTimestamp": 1749733121.4242022,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "137",
        "ingestTimestamp": 1749733121.4644225,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "138",
        "ingestTimestamp": 1749733121.5082908,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "139",
        "ingestTimestamp": 1749733121.5511975,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "140",
        "ingestTimestamp": 1749733121.5935106,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "141",
        "ingestTimestamp": 1749733121.6385624,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "142",
        "ingestTimestamp": 1749733121.6804419,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "143",
        "ingestTimestamp": 1749733121.7216706,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "144",
        "ingestTimestamp": 1749733121.7690315,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "145",
        "ingestTimestamp": 1749733121.8119755,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "146",
        "ingestTimestamp": 1749733121.8602052,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "147",
        "ingestTimestamp": 1749733121.9088585,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "148",
        "ingestTimestamp": 1749733121.9499164,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "149",
        "ingestTimestamp": 1749733121.9895303,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "150",
        "ingestTimestamp": 1749733122.0333395,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "151",
        "ingestTimestamp": 1749733122.0825784,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    },
    {
        "PartitionKey": "6bc287a8-a1e1-4617-a47f-6ac78b340d45",
        "RowKey": "152",
        "ingestTimestamp": 1749733122.1274786,
        "jobStatus": "QUEUED",
        "jobType": "ASSET_EXPORT_JOB",
        "startTime": 1749733025,
        "updateCheckpoint": False
    }
]
        # sorted_chunks = json.dumps(json)
        logging.info(f"{logs_starts_with} {function_name}: Sorted chunks length: {len(json_data)}")
        str_activity_data = json.dumps(json_data)
        status, jobs_with_finished_chunks = yield context.call_activity(
            asset_download_and_process_chunk_activity_name, str_activity_data
        )
        logging.info(f"{logs_starts_with} {function_name}: Activity status: {status}")
        logging.info(f"{logs_starts_with} {function_name}: Jobs with finished chunks: {jobs_with_finished_chunks}")
        if status:
            break
        if not status:
            download_chunk_schedule_minutes = retry_interval
            logging.error(
                f"{logs_starts_with} {function_name}: Activity failed with status code "
                f"401 or 403. Sleeping for {download_chunk_schedule_minutes} minutes...")
            break
        try:
            jobs_with_finished_chunks = json.loads(jobs_with_finished_chunks)
        except json.JSONDecodeError as json_err:
            logging.error(
                f"{logs_starts_with} {function_name}: Error while loading JSON data from activity. Error: {json_err}"
            )
            raise Exception(json_err)
        logging.info(f"{logs_starts_with} {function_name}: Number of finished chunks by job id: {jobs_with_finished_chunks}")

    next_check = context.current_utc_datetime + timedelta(minutes=download_chunk_schedule_minutes)
    logging.info(f"{logs_starts_with} {function_name}: Will check at time: {next_check}")
    yield context.create_timer(next_check)
    yield context.continue_as_new(None)


main = df.Orchestrator.create(orchestrator_function)
