"""Asset DownloadChunk Orchestrator file"""

import json
import logging
import os

import azure.durable_functions as df

from datetime import timedelta
from ..exports_store import (
    ExportsTableStore,
    ExportsTableNames,
    list_tables_in_storage_account,
)

connection_string = os.environ["AzureWebJobsStorage"]
assets_table_name = ExportsTableNames.TenableAssetExportTable.value
assets_table = ExportsTableStore(connection_string, assets_table_name)
download_chunk_schedule_minutes = 1

logs_starts_with = "TenableVM"
function_name = "TenableAssetDownloadChunkOrchestrator"


def check_table_exist():
    tables = list_tables_in_storage_account(connection_string)
    for table in tables:
        if table.name == assets_table_name:
            logging.info(
                f"{logs_starts_with} {function_name}: {assets_table_name} table exists."
            )
            return True
    return False


def orchestrator_function(context: df.DurableOrchestrationContext):
    """
    Orchestrator function to download chunks from Tenable.io Assets export job.

    Args:
        context: The durable orchestration context

    Returns:
        A list containing the results of three parallel activity calls to download three chunks from TenableAssetsExportJob
    """
    logging.info(
        f"{logs_starts_with} {function_name}: Starting execution for TenableAssetDownloadChunkOrchestrator"
    )
    logging.info(
        f"{logs_starts_with} {function_name}: instance id: {context.instance_id} at {context.current_utc_datetime}"
    )
    jobs_with_finished_chunks = {}
    flag = check_table_exist()
    if not flag:
        logging.info(
            f"{logs_starts_with} {function_name}:{assets_table_name} table is not creaed. waiting for next execution."
        )
        next_check = context.current_utc_datetime + timedelta(
            minutes=download_chunk_schedule_minutes
        )
        yield context.create_timer(next_check)
        context.continue_as_new(None)
    while True:
        queued_chunks = assets_table.query_for_all_queued_chunks()
        queued_chunks_list = list(queued_chunks)
        logging.info(
            f"{logs_starts_with} {function_name}: Number of queued chunks: {len(queued_chunks_list)}"
        )
        if len(queued_chunks_list) == 0:
            logging.info(
                f"{logs_starts_with} {function_name}: No more chunks found to process. Will go to sleep for 1 minute..."
            )
            break
        sorted_chunks = sorted(queued_chunks_list, key=lambda e: e["ingestTimestamp"])

        str_activity_data = json.dumps(sorted_chunks)
        jobs_with_finished_chunks = yield context.call_activity(
            "TenableAssetDownloadAndProcessChunks", str_activity_data
        )
        logging.info(
            f"{logs_starts_with} {function_name}: Jobs with finished chunks count: {jobs_with_finished_chunks}"
        )

    next_check = context.current_utc_datetime + timedelta(
        minutes=download_chunk_schedule_minutes
    )
    yield context.create_timer(next_check)
    context.continue_as_new(None)


main = df.Orchestrator.create(orchestrator_function)
