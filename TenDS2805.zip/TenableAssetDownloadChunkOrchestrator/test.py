a = 0
b = True
def test():
    global a
    while True:
        if b:
            a += 1
            break
        a = 0
test()
test()
test()
b = False
test()
print(a)