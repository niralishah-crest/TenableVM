import json
import logging
import os
import time

from ..exports_store import ExportsTableStore, ExportsTableNames
from ..tenable_helper import TenableIO, TenableStatus, TenableExportType, update_checkpoint_for_last_chunk

connection_string = os.environ["AzureWebJobsStorage"]
assets_table_name = ExportsTableNames.TenableAssetExportTable.value
logs_starts_with = "TenableVM"
function_name = "TenableAssetExportStatusAndSendChunks"


def add_chunks_to_table(exportJobDetails):
    logging.info(f"{logs_starts_with} {function_name}: Adding chunk to the table.")
    chunks = exportJobDetails.get("chunks_available", [])
    exportJobId = exportJobDetails.get("exportJobId", "")
    start_time = exportJobDetails.get("start_time", 0)
    job_status = exportJobDetails.get("status", "")

    if len(chunks) > 0:
        assets_table = ExportsTableStore(connection_string, assets_table_name)
        update_checkpoint = False
        for chunk in chunks:
            update_checkpoint = update_checkpoint_for_last_chunk(chunk, chunks, job_status)
            chunk_dtls = assets_table.get(exportJobId, str(chunk))
            if chunk_dtls:
                current_chunk_status = chunk_dtls["jobStatus"]
                if (
                        current_chunk_status == TenableStatus.queued.value or
                        current_chunk_status == TenableStatus.finished.value
                ):
                    logging.info(f"{logs_starts_with} {function_name}: Avoiding asset chunk duplicate processing -- {exportJobId} {chunk}. Current status: {current_chunk_status}")
                    continue

            logging.info(f"{logs_starts_with} {function_name}: Chunk added to the table -- {exportJobId} {chunk}")
            assets_table.merge(exportJobId, str(chunk), {
                "jobStatus": TenableStatus.queued.value,
                "startTime": start_time,
                "updateCheckpoint": update_checkpoint,
                "jobType": TenableExportType.asset.value,
                "ingestTimestamp": int(time.time()),
                })
    else:
        logging.info(f"{logs_starts_with} {function_name}: No chunk found to process.")
        return


def main(exportJob: str) -> object:
    jsonExportObject = json.loads(exportJob)
    exportJobId = jsonExportObject.get("asset_job_id", "")
    start_time = jsonExportObject.get("start_time", 0)
    logging.info(f"{logs_starts_with} {function_name}: Using pyTenable client to check asset export job status")
    logging.info(
        f"{logs_starts_with} {function_name}: checking status at assets/{exportJobId}/status")
    tio = TenableIO()
    job_details = tio.exports.status("assets", exportJobId)
    logging.info(
        f"{logs_starts_with} {function_name}: Received a response from assets/{exportJobId}/status")
    logging.info(f"{logs_starts_with} {function_name}: {job_details}")

    tio_status = ["ERROR", "CANCELLED"]
    if job_details["status"] not in tio_status:
        try:
            job_details["exportJobId"] = exportJobId
            job_details["start_time"] = start_time
            add_chunks_to_table(job_details)
        except Exception as e:
            logging.warning(f"{logs_starts_with} {function_name}: Error while adding chunks to table")
            logging.warning(f"{logs_starts_with} {function_name}: {job_details}")
            logging.warning(f"{logs_starts_with} {function_name}: Error: {e}")
    else:
        logging.info(f"{logs_starts_with} {function_name}: Asset export job status: {job_details["status"]}")

    return job_details
