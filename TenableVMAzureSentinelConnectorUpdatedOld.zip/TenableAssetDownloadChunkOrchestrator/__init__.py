"""Asset DownloadChunk Orchestrator file"""

import json
import logging
import os

import azure.durable_functions as df

from datetime import timedelta
from operator import itemgetter, attrgetter
from ..exports_store import ExportsTableStore, ExportsTableNames, list_tables_in_storage_account
from ..azure_sentinel import AzureSentinel
from ..tenable_helper import TenableIO, TenableStatus, TenableChunkPartitioner
from tenable.errors import APIError

connection_string = os.environ["AzureWebJobsStorage"]
assets_table_name = ExportsTableNames.TenableAssetExportTable.value
checkpoint_table_name = ExportsTableNames.TenableExportCheckpointTable.value
workspace_id = os.environ["WorkspaceID"]
workspace_key = os.environ["WorkspaceKey"]
log_analytics_uri = os.getenv("LogAnalyticsUri", "")
log_type = "Tenable_VM_Assets_old_1442_CL"
assets_table = ExportsTableStore(connection_string, assets_table_name)
download_chunk_schedule_minutes = 1
status_code_exceptions = [400, 401, 403, 404, 429]
logs_starts_with = "TenableVM"
function_name = "TenableAssetDownloadOrchestrator"

# def raise_api_errors(job_id, chunk_id, error: APIError):
#     logging.error(
#         f"Error in downloading chunk at assets/{job_id}/chunks/{chunk_id}. status code: error.code{error.code}, reason: {error.response}"
#     )

# def download_chunk_details(job_id, chunk_id):
#     logging.info(
#         f"{logs_starts_with} {function_name}:Using pyTenable client to download asset export job chunk")
#     logging.info(
#         f"{logs_starts_with} {function_name}:Downloading chunk at assets/{job_id}/chunks/{chunk_id}")
#     tio = TenableIO()
#     try:
#         chunk = tio.exports.download_chunk("assets", job_id, chunk_id)
#         logging.info(
#             f"{logs_starts_with} {function_name}:Received a response from assets/{job_id}/chunks/{chunk_id}")
#         return chunk
#     except APIError as e:
#         logging.warning(
#             f"{logs_starts_with} {function_name}:Failure to retrieve asset data from Tenable. Export Job ID: {job_id} Chunk ID: {chunk_id}")
#         raise_api_errors(job_id, chunk_id, e)
#         assets_table.update_if_found(job_id, str(chunk_id), {
#             "jobStatus": TenableStatus.failed.value,
#             "tenableFailedRequestStatusCode": e.code
#         })

# def send_chunk_details_to_sentinel(job_id, chunk_id, chunk, start_time, update_checkpoint):
#     try:
#         if len(chunk) == 0:
#             logging.info(f"{logs_starts_with} {function_name}:No data found in chunk, chunk_id: {chunk_id}, job_id: {job_id}")
#         else:
#             # limiting individual chunk uploaded to sentinel to be < 30 MB size.
#             sub_chunks = TenableChunkPartitioner.partition_chunks_into_30MB_sub_chunks(chunk)

#             for sub_chunk in sub_chunks:
#                 serialized_sub_chunk = json.dumps(sub_chunk)

#                 logging.info(f"{logs_starts_with} {function_name}:Uploading sub-chunk with size: %d", len(serialized_sub_chunk))

#                 # Send to Azure Sentinel here
#                 az_sentinel = AzureSentinel(
#                     workspace_id, workspace_key, log_type, log_analytics_uri)

#                 az_code = az_sentinel.post_data(serialized_sub_chunk)

#                 logging.info(f"{logs_starts_with} {function_name}:Data ingested into log analytics workspace table {assets_table_name}")

#         assets_table.update_if_found(job_id, str(chunk_id), {
#             "jobStatus": TenableStatus.finished.value
#         })
#         if update_checkpoint:
#             logging.info(f"{logs_starts_with} {function_name}:Updating Assets checkpoint to value: {start_time}")
#             checkpoint_table = ExportsTableStore(connection_string, checkpoint_table_name)
#             checkpoint_table.merge("assets", "timestamp", {
#                 "assets_timestamp": start_time
#             })
#     except Exception as e:
#         logging.error(e)

def check_table_exist():
    tables = list_tables_in_storage_account(connection_string)
    for table in tables:
        if table.name == assets_table_name:
            logging.info(f"{logs_starts_with} {function_name}: {assets_table_name} table exists.")
            return True
    return False

def orchestrator_function(context: df.DurableOrchestrationContext):
    """
    Orchestrator function to download chunks from Tenable.io Assets export job.

    Args:
        context: The durable orchestration context

    Returns:
        A list containing the results of three parallel activity calls to download three chunks from TenableAssetsExportJob
    """
    logging.info(f"{logs_starts_with} {function_name}:Starting execution for TenableAssetDownloadChunkOrchestrator")
    logging.info(
        f"{logs_starts_with} {function_name}:instance id: {context.instance_id} at {context.current_utc_datetime}")
    jobs_with_finished_chunks = {}
    flag = check_table_exist()
    if not flag:
        logging.info(f"{logs_starts_with} {function_name}:{assets_table_name} table is not creaed. waiting for next execution.")
        next_check = context.current_utc_datetime + timedelta(minutes=download_chunk_schedule_minutes)
        yield context.create_timer(next_check)
        context.continue_as_new(None)
    while True:    
        queued_chunks = assets_table.query_for_all_queued_chunks()
        queued_chunks_list = list(queued_chunks)
        logging.info(f"{logs_starts_with} {function_name}: Queued Chunks: {queued_chunks_list}")
        logging.info(f"{logs_starts_with} {function_name}: Number of queued chunks: {len(queued_chunks_list)}")
        if len(queued_chunks_list) == 0:
            logging.info(f"{logs_starts_with} {function_name}:No more chunks found to process. Will go to sleep for 1 minute...")
            break
        sorted_chunks = sorted(queued_chunks_list, key=lambda e: e["ingestTimestamp"])
        logging.info(f"{logs_starts_with} {function_name}: Sorted chunks: {sorted_chunks}")
        # for chunk in sorted_chunks:
        #     job_id = chunk.get("PartitionKey")
        #     chunk_id = chunk.get("RowKey")
        #     start_time = chunk.get("startTime")
        #     update_checkpoint = chunk.get("updateCheckpoint")
        #     if chunk.get("PartitionKey") not in jobs_with_finished_chunks:
        #         jobs_with_finished_chunks[job_id] = {
        #             "chunks": [{"chunk_id": chunk_id, "start_time": start_time, "update_checkpoint": update_checkpoint}]
        #         }
        #     else:
        #         jobs_with_finished_chunks[job_id]["chunks"].append({"chunk_id": chunk_id, "start_time": start_time, "update_checkpoint": update_checkpoint})
        
        # sorted_jobs = sorted(jobs_with_finished_chunks, key=attrgetter("Timestamp"))
        # logging.info(f"Jobs in sorted orders: {sorted_jobs}")
        str_activity_data = json.dumps(sorted_chunks)
        jobs_with_finished_chunks = yield context.call_activity("TenableAssetDownloadAndProcessChunks", str_activity_data)
        logging.info(f"{logs_starts_with} {function_name}:Jobs with finished chunks count: {jobs_with_finished_chunks}")
        # for job_id in jobs_with_finished_chunks.keys():
        #     chunk_count = 0
        #     sorted_job_chunks = sorted(jobs_with_finished_chunks[job_id]["chunks"], key=attrgetter("chunk_id"))
        #     logging.info(f"{logs_starts_with} {function_name}:Chunks in sorted order for job {job_id}: {sorted_job_chunks}")
        #     logging.info(f"{logs_starts_with} {function_name}:Total {sorted_job_chunks} chunks available to process for job_id {job_id}")
        #     for chunk in sorted_job_chunks:
        #         chunk_data = download_chunk_details(job_id, chunk.get("chunk_id"))
        #         send_chunk_details_to_sentinel(job_id, chunk.get("chunk_id"), chunk_data, chunk.get("start_time"), chunk.get("update_checkpoint"))
        #         chunk_count += 1
        #     logging.info(f"{logs_starts_with} {function_name}:Completed downloading and processing {chunk_count} chunks for job id: {job_id}")
    
    next_check = context.current_utc_datetime + timedelta(minutes=download_chunk_schedule_minutes)
    yield context.create_timer(next_check)
    context.continue_as_new(None)

main = df.Orchestrator.create(orchestrator_function)
