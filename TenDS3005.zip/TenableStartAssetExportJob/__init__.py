"""Start Asset Export Job file."""

import logging
import os

from ..tenable_helper import TenableIO, TenableStatus
from tenable.errors import APIError
from ..exports_store import (
    ExportsTableStore,
    ExportsTableNames,
)

logs_starts_with = "TenableVM"
function_name = "TenableStartAssetExportJob"
connection_string = os.environ["AzureWebJobsStorage"]
assets_table_name = ExportsTableNames.TenableAssetExportTable.value
assets_table = ExportsTableStore(connection_string, assets_table_name)


def update_chunk_status_in_batch(chunks_to_be_updated: dict):
    """Updates the status of chunks in the table in batches.

    Args:
        chunks_to_be_updated (dict): A dictionary with job_id as key and a list of tuples containing the action, data and options as values.
            The tuple is in the format of (action, data, options). The action is always "upsert", data is the data to be updated and options is a dictionary with the mode as "merge".
    """
    batch_size = 50
    for job in chunks_to_be_updated.keys():
        batches = [
            chunks_to_be_updated[job][i: i + batch_size]
            for i in range(0, len(chunks_to_be_updated[job]), batch_size)
        ]
        try:
            for batch in batches:
                logging.debug(f"{logs_starts_with} {function_name}: Updating data in batch for job_id: {job}")
                assets_table.batch(batch)
        except Exception as e:
            logging.error(f"{logs_starts_with} {function_name}: Error in updating chunk status in batch: {e}")

def update_chunk_status_for_old_jobs() -> None:
    """This function updates the status of chunks in the table to EXPIRED if they are queued but the job has not been polled in a while.
    It is used to prevent the chunk from remaining in the queue indefinitely if the job is not polled.
    """
    chunks_to_be_updated = {}
    logging.info(f"{logs_starts_with} {function_name}: Updating chunk status to EXPIRED for old jobs.")
    queued_chunks = assets_table.query_for_all_queued_chunks()
    queued_chunks_list = list(queued_chunks)
    for chunk in queued_chunks_list:
        job_id = chunk.get("PartitionKey")
        chunk_id = chunk.get("RowKey")
        if job_id not in chunks_to_be_updated:
            chunks_to_be_updated[job_id] = [("upsert", {"PartitionKey": job_id, "RowKey": chunk_id, "jobStatus": TenableStatus.expired.value}, {"mode": "merge"})]
        else:
            chunks_to_be_updated[job_id].append(("upsert", {"PartitionKey": job_id, "RowKey": chunk_id, "jobStatus": TenableStatus.expired.value}, {"mode": "merge"}))
    
    update_chunk_status_in_batch(chunks_to_be_updated)

def main(timestamp: int) -> object:
    """
    Create a new asset export job using the pyTenable client.

    Args:
    timestamp (int): The timestamp after which assets should be exported.

    Returns:
    object: The job ID of the created asset export job as a string.
    """
    logging.info(f"{logs_starts_with} {function_name}: Using pyTenable client to create new asset export job")
    update_chunk_status_for_old_jobs()
    tio = TenableIO()
    logging.info(
        f"{logs_starts_with} {function_name}: Requesting a new Asset Export Job from Tenable for timestamp={timestamp}"
    )
    # limiting chunk size to contain 1000 assets details. For some bigger
    # containers, each chunk is reported to be some hundreds of MBs resulting
    # into azure function crash due to OOM errors.
    try:
        job_id = tio.exports.assets(updated_at=timestamp, chunk_size=1000, use_iterator=False)
    except APIError as e:
        logging.warning(f"{logs_starts_with} {function_name}: Failure to create a new asset export job.")
        logging.error(
            f"{logs_starts_with} {function_name}: Error in creating asset export job status. status code: error.code {
                e.code}, reason: {
                e.response}"
        )
        raise Exception(
            f"Creating an asset export job from Tenable failed with error code {e.code}, reason: {e.response}"
        )
    logging.info(f"{logs_starts_with} {function_name}: Received a response from Asset Export Job request {job_id}")
    return str(job_id)
