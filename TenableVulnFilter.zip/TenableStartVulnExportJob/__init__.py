import logging
import os

from ..tenable_helper import TenableIO

severity = os.environ.get('Vuln_Severity', '')
SEVERITIES = ['info', 'low', 'medium', 'high', 'critical']
def main(timestamp: int) -> object:
    logging.info('using pyTenable client to create new vuln export job')
    tio = TenableIO()
    logging.info(
        f'requesting a new Vuln Export Job from Tenable')
    # limiting number of assets to 50. For some bigger containers, 
    # each chunk is reported to be some hundreds of MBs resulting
    # into azure function crash due to OOM errors.
    if severity:
        logging.info("Selected lowest severity: {}".format(severity))
        logging.info("Fetching vulnerability Data for severity: {}".format(SEVERITIES[SEVERITIES.index(severity):]))
        job_id = tio.exports.vulns(last_found=timestamp, num_assets=50, severity=SEVERITIES[SEVERITIES.index(severity):])
    else:
        job_id = tio.exports.vulns(last_found=timestamp, num_assets=50)

    logging.info(f'received a response from Vuln Export Job request')
    logging.info(job_id)
    return job_id
